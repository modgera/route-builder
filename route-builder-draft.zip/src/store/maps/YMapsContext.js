
import { createContext } from "react";

export const YMapsContext = createContext(null);

export const MapContext = createContext(null);