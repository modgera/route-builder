import PointInput from "./PointInput";

export default PointInput;
