import Point from "./Point";

export default Point;
