import React, {useContext, useState} from 'react';

import {YMapsContext, MapContext} from '../../store/maps/YMapsContext';
import  {getUserLocation} from '../../services/yandexMap';

const Map = ({children}) => {
	const { ymaps } = useContext(YMapsContext);
	const [location, setLocation] = useState(null);
	const [map, setMap] = useState(null);
	if (!map) {
		getUserLocation(ymaps, setLocation);
		if (location) {
			const newMap = new ymaps.Map("YMapsID", {
				center: location,
				zoom: 12
			});  
			setMap(newMap);
		}
	}
	
	return <MapContext.Provider value={map}> {children}</MapContext.Provider>;
}

export default Map;