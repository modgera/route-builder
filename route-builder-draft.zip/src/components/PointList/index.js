import PointList from "./PointList";

export default PointList;
